class Film:
    
    def __init__(self, cim, ev):
        self.cim = cim
        self.ev = ev
       

#Terminál, 2004, amerikai
#Sose halunk meg, 1993, magyar
#Bíbor folyók, 2000, francia
#A séf, 2014, amerikai
#A tanú, 1977, magyar