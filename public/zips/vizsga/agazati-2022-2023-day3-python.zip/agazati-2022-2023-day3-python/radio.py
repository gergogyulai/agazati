#90,40	0,200	Európa Rádió	128
#98,30	5,01	Retro Rádió	229
#101,60	1	Rádió M	229
#103,80	3	Karc FM	229

class Radio:
    def __init__(self, frekv, nev, magassag):
        self.frekvencia = frekv #MHz-ben
        self.nev = nev
        self.magassag = magassag #tengerszint feletti magasság méterben

    