
var bekezdesek = document.getElementsByTagName("p");
console.log(bekezdesek);
console.log(bekezdesek.length);
let words = []
for (const p of bekezdesek) {
  var szavak = p.innerText.split(' ');
  for (const szo of szavak) {
    if (!words.includes(szo))
      words.push(szo)
  }
}


function showSuggestions() {
  var input = document.getElementById("searchInput");
  var query = input.value.toLowerCase();
  var suggestionList = document.getElementById("suggestionList");
  suggestionList.innerHTML = "";

  if (query.length > 2) {
    var matchingWords = words.filter(function (word) {
      return word.startsWith(query);
    });

    matchingWords.forEach(function (word) {
      var li = document.createElement("li");
      li.textContent = word;
      li.className = "list-group-item";
      suggestionList.appendChild(li);
      console.log(word);
    });
  }
}
