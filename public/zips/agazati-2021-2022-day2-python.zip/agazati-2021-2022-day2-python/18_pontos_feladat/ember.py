class Ember:
    def __init__(self, név, szül_év):
        self.név = név
        self.szül_év = szül_év
